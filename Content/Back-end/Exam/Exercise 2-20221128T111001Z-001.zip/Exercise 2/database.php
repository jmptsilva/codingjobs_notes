<?php

$conn = new PDO('mysql:host=localhost;dbname=space', 'root', '');
