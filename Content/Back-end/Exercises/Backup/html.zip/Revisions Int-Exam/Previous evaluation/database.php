<?php

$conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'music_shop');
