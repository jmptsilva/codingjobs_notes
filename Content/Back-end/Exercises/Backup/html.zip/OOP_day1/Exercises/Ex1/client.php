<?php

require_once 'Human.php';

// Create the objects

$human1 = new Human('Afonso', 'brown', 'male', '1,88');

$human2 = new Human('Jay', 'brown', 'female', '1,52');

echo $human1;
echo $human2;

/* echo '<pre>';
var_dump($human1);
echo '</pre>'; */