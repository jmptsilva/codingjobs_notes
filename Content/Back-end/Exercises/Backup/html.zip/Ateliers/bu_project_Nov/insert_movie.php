<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert new movie</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>

<body>
    <?php
    require_once "nav.php";

    if (isset($_POST['insertBtn'])) {
        $errors = false;

        $title = strip_tags(trim($_POST['titleInput']));
        $description = strip_tags(trim($_POST['descripInput']));
        $date = strip_tags(trim($_POST['dateInput']));
        $poster = strip_tags(trim($_POST['posterInput']));
        $director = $_POST['director'];

        if (empty($title)) {
            $errors = true;
            echo "Must enter a valid name!";
        }
        if (empty($description)) {
            $errors = true;
            echo "Must enter a valid description!";
        }
        if (empty($poster)) {
            $errors = true;
            echo "Must enter a valid poster url!";
        }
        if (empty($date)) {
            $errors = true;
            echo "Must enter a valid year of release!";
        }


        if ($errors == false) {
            $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

            if ($conn) {
                echo "<br>Connected successfully!<br>";
                $query = "INSERT INTO movies(title, release_date, description, poster, director_id)
                VALUES('$title', '$date', '$description', '$poster', '$director')";

                $result = mysqli_query($conn, $query);
                mysqli_close($conn);

                echo "Successfully inserted a movie!<br>";
            } else {
                echo "Invalid input; try again.";
            }
        } else {
            echo "Not connected.";
        }
    }


    ?>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <form method="post">
                    <input class="form-control m-2" placeholder="Movie name" name="titleInput">
                    <input class="form-control m-2" placeholder="Year of release" name="dateInput">
                    <input class="form-control m-2" placeholder="Description" name="descripInput">
                    <input class="form-control m-2" placeholder="Poster URL" name="posterInput">
                    <select name="director">
                        <?php
                        $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');
                        $query = "SELECT *
                        FROM directors";
                        $result = mysqli_query($conn, $query);
                        $directors = mysqli_fetch_all($result, MYSQLI_ASSOC);
                        mysqli_close($conn);
                        ?>
                        <?php foreach ($directors as $director) : ?>
                            <option value="<?= $director['id']; ?>"><?= $director['first_name'] . ' ' . $director['last_name']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn btn-dark" type="submit" name="insertBtn">Insert</button>
                </form>
            </div>
        </div>
    </div>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

</body>

</html>