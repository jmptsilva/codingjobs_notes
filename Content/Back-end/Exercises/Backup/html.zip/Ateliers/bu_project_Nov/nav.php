<section class="bg-color-lg">
    <div class="container">
        <div class="row p-3 g-3">
            <div class="d-flex col-12 justify-content-between">
                <div class="d-flex links align-items-center">
                    <div class="mx-2">
                        <a href="./">Home</a>
                    </div>
                    <div class="mx-2">
                        <a href="movies.php">Movies</a>
                    </div>
                    <div class="mx-2">
                        <a href="directors.php">Directors</a>
                    </div>
                    <div class="mx-2">
                        <a href="insert_movie.php">Add new movie</a>
                    </div>
                </div>
                <?php
                if ($isLoggedIn) {
                    echo '<div class="d-flex links align-items-center">
                            <div class="mx-2">
                                <a href="user_account.php">Account</a>
                            </div>
                        </div>';
                } else {
                    echo '<div class="d-flex links align-items-center">
                            <div class="mx-2">
                                <a href="register.php">Register</a>
                            </div>
                            <div class="mx-2">
                                <a href="login.php">Login</a>
                            </div>
                        </div>';
                }
                ?>

            </div>
        </div>
    </div>
</section>
<style>
    .search-btn {
        background-color: black;
    }

    a {
        text-decoration: none;
        color: black;
    }

    .bg-color-lg {
        background-color: lightgray;
    }
</style>