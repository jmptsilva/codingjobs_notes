<?php
$conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

$query = "SELECT *
FROM movies
WHERE id =" . $_GET['id'];

$result = mysqli_query($conn, $query);
$movie = mysqli_fetch_all($result, MYSQLI_ASSOC);
mysqli_close($conn);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Details</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>

<body>
    <?php
    require_once "nav.php";

    ?>
    <div class="container">
        <div class="row mt-5">
            <div class="col-12 d-flex align-items-center">
                <div class="d-flex flex-column p-2">
                    <p>
                        <strong><?= $movie[0]['title']; ?></strong>

                    </p>
                    <img src="./assets/images/<?= $movie[0]['poster']; ?>" alt="movie poster" width="200px">
                </div>
                <div class="p-2">
                    <p>
                        <strong>Description : </strong>
                        <?= $movie[0]['description']; ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

</body>

</html>