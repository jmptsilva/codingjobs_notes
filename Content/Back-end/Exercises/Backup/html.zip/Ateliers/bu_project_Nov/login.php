<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>

<body>


    <?php
    require_once "nav.html";
    // Make sure button was clicked
    if (isset($_POST['loginBtn'])) {
        $errors = false;
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Check if email and password are not empty
        if (empty($email)) {
            $errors = true;
            echo 'Email is mandatory<br>';
        }

        if (empty($password)) {
            $errors = true;
            echo 'Password is mandatory<br>';
        }

        // If NO errors
        if (!$errors) {
            /* $_SESSION['email'] = $_POST['email']; */
            $conn = mysqli_connect('localhost', 'root', '', 'bu_project');

            if ($conn) {
                /* echo "<br>Connected successfully!<br>"; */
                $query = "SELECT * 
                FROM users
                WHERE email = '$email'";

                $result = mysqli_query($conn, $query);
                $useraccount = mysqli_fetch_all($result, MYSQLI_ASSOC);
                mysqli_close($conn);
                if (empty($useraccount)){
                    echo " User not found, Please register";
                } else {
                    if ( password_verify($password, $useraccount[0]['password'] )){
                        echo" Welcome back!!";
                    }
                }

                echo "<pre>";
                var_dump($useraccount);
                echo "</pre>";
               
        }
    }
}
?>
    
    <div class="container">
        <div class="row m-3">
            <h1>Login</h1>
            <form method="POST">
                <input type="text" name="email" placeholder="Your email"><br>
                <input type="text" name="password" placeholder="Your password"><br>
                <input type="submit" name="loginBtn" value="Log in">
            </form>
        </div>
    </div>

    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
</body>

</html>