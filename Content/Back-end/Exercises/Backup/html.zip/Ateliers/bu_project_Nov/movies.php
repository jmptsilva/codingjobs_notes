<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movies list</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>

<body>
    <?php
    require_once "nav.php";

    ?>

    <div class="container my-5">
        <div class="row">
            <div class="col-12 col-md-6 d-flex flex-column align-items-start">
                <h1 class="mb-5">Movies</h1>
                <div class="d-flex">
                    <form method="post" class="d-flex" role="search">
                        <input class="form-control me-2" placeholder="Movie name..." name="searchInput">
                        <button class="search-btn btn btn-dark" type="submit" name="searchBtn">Search</button>
                    </form>
                </div>
            </div>
            <div class="col-12 col-md-6 d-flex align-items-center">
                <div class="filters d-flex mt-3">
                    <div class="mx-3">
                        <p>
                            <strong>Filter by title</strong>
                        </p>
                        <form method="post">
                            <button class="btn btn-dark m-1" type="submit" name="ascTitle">Ascending</button>
                            <button class="btn btn-dark m-1" type="submit" name="descTitle">Descending</button>
                        </form>
                    </div>
                    <div class="mx-3">
                        <p>
                            <strong>Filter by date</strong>
                        </p>
                        <form method="post">
                            <button class="btn btn-dark m-1" type="submit" name="ascDate">Ascending</button>
                            <button class="btn btn-dark m-1" type="submit" name="descDate">Descending</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="container">
        <div class="row g-5">
            <?php

            $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

            $query = "SELECT *
            FROM movies
            ORDER BY title ASC";

            $result = mysqli_query($conn, $query);
            $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
            mysqli_close($conn);

            if (isset($_POST['ascTitle'])) {
                $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

                $query = "SELECT *
                FROM movies
                ORDER BY title ASC";

                $result = mysqli_query($conn, $query);
                $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
                mysqli_close($conn);
            }

            if (isset($_POST['descTitle'])) {
                $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

                $query = "SELECT *
                FROM movies
                ORDER BY title DESC";

                $result = mysqli_query($conn, $query);
                $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
                mysqli_close($conn);
            }
            if (isset($_POST['ascDate'])) {
                $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

                $query = "SELECT *
                FROM movies
                ORDER BY release_date ASC";

                $result = mysqli_query($conn, $query);
                $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
                mysqli_close($conn);
            }

            if (isset($_POST['descDate'])) {
                $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

                $query = "SELECT *
                FROM movies
                ORDER BY release_date DESC";

                $result = mysqli_query($conn, $query);
                $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
                mysqli_close($conn);
            }

            if (isset($_POST['searchBtn'])) {
                $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');

                $input = "'%" . $_POST['searchInput'] . "%'";

                $query = "SELECT *
                FROM movies
                WHERE title LIKE $input";

                $result = mysqli_query($conn, $query);
                $movies = mysqli_fetch_all($result, MYSQLI_ASSOC);
                mysqli_close($conn);
            }

            ?>
            <?php foreach ($movies as $movie) : ?>
                <div class="col-12 col-md-6">
                    <p>
                        <strong>Title : </strong>
                        <?= $movie['title']; ?>
                    </p>
                    <img src="./assets/images/<?= $movie['poster']; ?>" alt="movie poster" width="200px">
                    <p>
                        <strong>Description : </strong>
                        <?= $movie['description']; ?>
                    </p>
                    <a href="movie_detail.php?id=<?= $movie['id']; ?>">More details</a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

</body>

</html>