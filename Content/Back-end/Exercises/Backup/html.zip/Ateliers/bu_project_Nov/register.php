<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

</head>

<body>
    <?php require_once 'nav.php'; ?>

    <div class="container">
        <h1 class="mt-5">Register</h1>
    </div>

    <?php

    if (isset($_POST['registerBtn'])) {
        $username = strip_tags(trim($_POST['username']));
        $email = trim($_POST['email']);
        $sanitizedEmail = filter_var($email, FILTER_SANITIZE_EMAIL);

        $password = $_POST['password'];
        $cPassword = $_POST['cPassword'];

        $errors = false;

        if (empty($username)) {
            echo "Name is mandatory!<br>";
            $errors = true;
        }

        if (empty($sanitizedEmail)) {
            echo "Email is mandatory<br>";
            $errors = true;
        } else if (!filter_var($sanitizedEmail, FILTER_VALIDATE_EMAIL)) {
            echo "Email is not valid<br>";
            $errors = true;
        }

        if (empty($password)) {
            echo "Password is mandatory<br>";
            $errors = true;
        } else if ($password != $cPassword) {
            echo "Passwords are not matching<br>";
            $errors = true;
        }

        // Only if no errors 
        if (!$errors) {
            $hashPassword = password_hash($password, PASSWORD_DEFAULT);

            $conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'bu_project');
            $query = "INSERT INTO users(name, email, password)
            VALUES('$username', '$email', '$hashPassword')";
            $result = mysqli_query($conn, $query);
            mysqli_close($conn);

            if ($result)
                echo "<p style='color: green'>Successfully registered</p>";
            else
                echo "<p style='color: red'>Problem registering</p>";
        }
    }

    ?>

    <div class="container mt-5">
        <div class="row">
            <form method="post">
                <input class="m-2" type="text" name="username" placeholder="Name"><br>
                <input class="m-2" type="text" name="email" placeholder="Email"><br>
                <input class="m-2" type="text" name="password" placeholder="Password"><br>
                <input class="m-2" type="text" name="cPassword" placeholder="Confirm password"><br>
                <input class="m-2" type="submit" name="registerBtn" value="Register"><br>
            </form>
        </div>
    </div>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>

</body>

</html>