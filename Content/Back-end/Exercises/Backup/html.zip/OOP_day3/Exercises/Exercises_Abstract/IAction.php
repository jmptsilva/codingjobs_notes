<?php

interface IAction
{
    public function work();
}
