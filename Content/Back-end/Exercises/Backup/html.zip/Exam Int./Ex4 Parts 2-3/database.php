<?php

$conn = mysqli_connect('localhost', 'jsilva', 'j0m4n3ls', 'christmas_shop');
