<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Loops Ex.8</title>
</head>

<body>
    <?php

    $numbers = [3, 4, 1, 5, 2, 9, 6, 10, 7];

    $var = 0;

    for ($i = 1; $i <= count($numbers) + 1; $i++) {
    }

    // echo $var;

    ?>
</body>

</html>