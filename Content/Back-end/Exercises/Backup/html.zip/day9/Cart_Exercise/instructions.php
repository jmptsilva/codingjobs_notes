<?php

/*

    - Step 1 : 
    Edit 'books.php' page.
    For each book, add a button/link 'add to cart'

    When you click on the button, it should add the book to the cart.

    - Step 2 :

    Edit nav.php
    You should be able to see, in the nav, the number of books inside your cart.
    When you add a book to the cart, it should update this number.

    - Step 3 : 

    Edit 'cart.php' page.
    Display every books from your cart and display total price.
    If cart is empty display a message "your cart is empty"

*/