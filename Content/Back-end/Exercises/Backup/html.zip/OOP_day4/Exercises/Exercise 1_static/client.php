<?php

require_once 'Utility.php';

Utility::add_log();
