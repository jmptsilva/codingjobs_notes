<?php

class Flower
{
    public $id;
    public $name;
    public $price;
}
